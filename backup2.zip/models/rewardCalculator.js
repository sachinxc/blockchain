class RewardCalculator {
  constructor() {
    this.baseReward = 2;
  }

  // Method to calculate the reward
  calculateReward() {
    return this.baseReward;
  }
}

module.exports = RewardCalculator;
